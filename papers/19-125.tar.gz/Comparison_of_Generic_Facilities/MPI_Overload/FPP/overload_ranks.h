#define RANK_ 0

#include "overload.h"
#include "bcast.h"
#include "gather.h"
#include "scatter.h"

#undef RANK_


#define RANK_ 1

#include "overload.h"
#include "bcast.h"
#include "gather.h"
#include "scatter.h"

#undef RANK_

#define RANK_ 2

#include "overload.h"
#include "bcast.h"
#include "gather.h"
#include "scatter.h"

#undef RANK_

#define RANK_ 3

#include "overload.h"
#include "bcast.h"
#include "gather.h"
#include "scatter.h"

#undef RANK_

#define RANK_ 4

#include "overload.h"
#include "bcast.h"
#include "gather.h"
#include "scatter.h"

#undef RANK_

#define RANK_ 5

#include "overload.h"
#include "bcast.h"
#include "gather.h"
#include "scatter.h"

#undef RANK_
